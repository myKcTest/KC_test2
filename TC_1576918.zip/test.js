// JavaScript Document
function test(){
	if(!undefined){
		console.log("Always Printed!!!!");
	}
	if(undefined){
	}
}