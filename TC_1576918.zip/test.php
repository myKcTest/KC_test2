<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Sample Test document</title>
    <style>
		.abc{
			/* one line css */	width: 100px;	}
		.bcd{
			/* Two line css */
		}
    </style>
</head>
<body>
	<p>
    1 line content</p>
    <p>
    2 line
    content </p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore, consequuntur, non, voluptatum distinctio dolore numquam quas sint illo sapiente accusantium ullam quam voluptatibus neque corporis corrupti sed commodi ipsa perspiciatis ipsam at odio excepturi repudiandae explicabo? Adipisci, architecto, recusandae, assumenda alias veniam laboriosam nemo neque nesciunt ipsum sed itaque magnam consequuntur repellendus maxime fugit eligendi at nulla praesentium sequi totam cupiditate obcaecati quos expedita animi ex tempore repellat id rem fugiat ad optio reiciendis minus delectus deleniti dolorem quaerat numquam. Perspiciatis, labore ipsum qui harum placeat maxime voluptate inventore assumenda quam a reiciendis non facere consequatur omnis delectus nam tempora.</p>
    
    <?php
	?>
    <?php
	
	?>
</body>
</html>